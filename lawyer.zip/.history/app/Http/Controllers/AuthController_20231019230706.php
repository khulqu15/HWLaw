<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Request;

class AuthController extends Controller {
    public function login(Request $request) {
    }
}

