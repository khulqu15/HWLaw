<?php $__env->startSection('title', "HWLawyer - $news->title" ); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('public.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="w-full pt-32 pb-12">
    <div class="w-full min-h-[50vh] relative">
        <img src="/assets/images/<?php echo e($news->cover); ?>" class="absolute top-0 left-0 w-full h-96 object-center object-cover opacity-40" alt="<?php echo e($news->cover); ?>">
        <div class="absolute top-0 left-0 w-full h-96 object-center object-cover bg-gradient-to-t from-white to-transparent"></div>
        <div class="relative container mx-auto md:px-16 pt-8">
            <a href="/news" class="btn btn-ghost border border-gray-300 mb-4">Kembali</a>
            <img src="/assets/images/<?php echo e($news->cover); ?>" alt="<?php echo e($news->cover); ?>" class="w-full rounded-xl">
            <h1 class="text-3xl break-words mt-4 mb-2 font-bold"><?php echo e($news->title); ?></h1>
            <div class="flex justify-start items-center gap-x-3">
                <div class="flex items-center gap-x-1">
                    <iconify-icon class="text-xl text-blue-900" icon="solar:calendar-date-bold"></iconify-icon>
                    <p class="break-words"><?php echo e(date('d M Y', strtotime($news->date))); ?></p>
                </div>
                <div class="flex items-center gap-x-1">
                    <iconify-icon class="text-xl text-blue-900" icon="heroicons:map-pin-20-solid"></iconify-icon>
                    <p class="break-words"><?php echo e($news->location); ?> </p>
                </div>
            </div>
            <div class="break-all mt-5">
                <?php echo $news->text; ?>

            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('public.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/lawyer/resources/views/public/news-detail.blade.php ENDPATH**/ ?>