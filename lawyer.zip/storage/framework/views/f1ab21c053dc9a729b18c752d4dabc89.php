<?php $__env->startSection('title', 'HW Lawyer - Data Client'); ?>

<?php $__env->startSection('navbar', 'Data Client'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full relative p-8 bg-white">
    <div class="space-y-3">
        <div>
            <?php if($count_clients > 0): ?>
            <div class="grid lg:grid-cols-1 gap-3 grid-cols-1">
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="collapse collapse-plus bg-base-200">
                    <input type="radio" name="my-accordion-3" checked="checked" />
                    <div class="collapse-title font-medium">
                        <div class="flex items-center justify-between">
                            <div>
                                <h2 class="text-lg"><?php echo e($item->name); ?></h2>
                                <span class="text-sm font-normal"><?php echo e($item->phone); ?> <?php echo e($item->phone != null && $item->email != null ? '|' : ''); ?> <?php echo e($item->email); ?></span>
                            </div>
                            <div class="relative z-40">
                                <form action="/private/client/<?php echo e($item->id); ?>" method="POST">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button onclick="return confirm('Yakin Hapus ?')" class="btn btn-error bg-red-400 btn-sm" type="submit">Hapus</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="collapse-content">
                        <div class="bg-white rounded-lg p-6">
                            <h4 class="text-lg font-semibold mb-2"><?php echo e($item->subject); ?></h4>
                            <?php echo $item->message; ?>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div id="pagination" class="flex space-x-3 justify-end mt-6">
                <div class="join space-x-3">
                    <?php echo e($clients->links()); ?>

                </div>
            </div>
            <?php else: ?>
            <div class="alert alert-error">
                <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <span>Data Area Praktek Masih Kosong !</span>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('private', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/lawyer/resources/views/private/partner/client.blade.php ENDPATH**/ ?>