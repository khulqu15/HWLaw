<?php $__env->startSection('title', 'HW Lawyer - Admin Area Praktek'); ?>

<?php $__env->startSection('navbar', 'Area Praktek'); ?>

<?php $__env->startSection('footer_script'); ?>
<script type="module" src="/assets/js/custom/practice.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full relative p-8 bg-white">
    <div class="space-y-3">
        <div>
            <a href="/private/practice/add" class="btn bg-blue-900 hover:bg-blue-700 text-white">Tambahkan baru</a>
        </div>
        <div>
            <?php if($count_practices > 0): ?>
            <div class="grid lg:grid-cols-2 gap-3 grid-cols-1">
                <?php $__currentLoopData = $practices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-compact bg-base-100 shadow-xl">
                    <figure><img src="/assets/images/<?php echo e($item->cover); ?>" class="w-full h-48 object-cover object-center" alt="Album"/></figure>
                    <div class="card-body">
                        <h2 class="card-title text-lg"><?php echo e($item->title); ?></h2>
                        <div class="justify-between items-center flex mt-3">
                            <a class="btn btn-success btn-sm" href="/private/practice/edit/<?php echo e($item->id); ?>">Edit</a>
                            <form action="/private/practice/delete/<?php echo e($item->id); ?>" method="POST">
                                <input type="hidden" name="_method" value="DELETE">
                                <button onclick="return confirm('Yakin Hapus Kategori ?')" class="btn btn-error bg-red-400 btn-sm" type="submit">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div id="pagination" class="flex space-x-3 justify-end mt-6">
                <div class="join space-x-3">
                    <?php echo e($practices->links()); ?>

                </div>
            </div>
            <?php else: ?>
            <div class="alert alert-error">
                <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <span>Data Area Praktek Masih Kosong !</span>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('private', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/lawyer/resources/views/private/practice/index.blade.php ENDPATH**/ ?>