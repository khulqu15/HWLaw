<?php $__env->startSection('title', 'HW Lawyer - Admin Update Informasi'); ?>

<?php $__env->startSection('navbar', 'Update Informasi'); ?>

<?php $__env->startSection('footer_script'); ?>
<script type="module" src="/assets/js/custom/news.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full relative p-8 bg-white">
    <div class="space-y-3">
        <div class="flex justify-between items-center gap-x-3">
            <div class="tabs tabs-boxed">
                <a href="/private/news" class="tab tab-active">Informasi</a>
                <a href="/private/news/categories" class="tab">Kategori</a>
            </div>
            <div>
                <a href="/private/news/add" class="btn bg-blue-900 hover:bg-blue-700 text-white">Tambahkan baru</a>
            </div>
        </div>
        <form class="flex items-center gap-x-3 justify-between">
            <div class="form_control grow w-full">
                <div class="input-group">
                    <input name="title" id="name_input" value="<?php echo e(request('title')); ?>" type="text" class="input text-sm w-full input-bordered" placeholder="Cari Berdasarkan Judul">
                    <button class="btn bg-primary" type="submit">
                        <iconify-icon icon="iconamoon:search-bold"></iconify-icon>
                    </button>
                </div>
            </div>
            <div class="form_control grow w-full">
                <div class="input-group">
                    <select name="category" id="category_input" class="select select-bordered w-full">
                        <option value="">Semua Kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(request('category') == $category->id ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="btn bg-primary" type="submit">
                        <iconify-icon icon="iconamoon:search-bold"></iconify-icon>
                    </button>
                </div>
            </div>
            <input type="hidden" value="<?php echo e(request('sort') == 'ASC' ? 'DESC' : 'ASC'); ?>" name="sort">
            <button class="btn bg-ghost text-black/70">
                <iconify-icon icon="fa:sort"></iconify-icon>
            </button>
        </form>
        <div>
            <?php if($count_news > 0): ?>
            <div class="grid lg:grid-cols-2 gap-3 grid-cols-1">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-compact bg-base-100 shadow-xl">
                    <figure><img src="/assets/images/<?php echo e($item->cover); ?>" class="w-full h-48 object-cover object-center" alt="Album"/></figure>
                    <div class="card-body">
                        <h2 class="card-title text-lg"><?php echo e($item->title); ?></h2>
                        <div class="flex justify-start items-center gap-x-3">
                            <div class="flex items-center gap-x-1">
                                <iconify-icon class="text-xl text-blue-900" icon="solar:calendar-date-bold"></iconify-icon>
                                <p class="text-sm"><?php echo e($item->date); ?></p>
                            </div>
                            <div class="flex items-center gap-x-1">
                                <iconify-icon class="text-xl text-blue-900" icon="heroicons:map-pin-20-solid"></iconify-icon>
                                <p class="text-sm"><?php echo e($item->location); ?></p>
                            </div>
                        </div>
                        <div class="justify-between items-center flex mt-3">
                            <a class="btn btn-success btn-sm" href="/private/news/edit/<?php echo e($item->id); ?>">Edit</a>
                            <form action="/private/news/delete/<?php echo e($item->id); ?>" method="POST">
                                <input type="hidden" name="_method" value="DELETE">
                                <button onclick="return confirm('Yakin Hapus Kategori ?')" class="btn btn-error bg-red-400 btn-sm" type="submit">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div id="pagination" class="flex space-x-3 justify-end mt-6">
                <div class="join space-x-3">
                    <?php echo e($news->links()); ?>

                </div>
            </div>
            <?php else: ?>
            <div class="alert alert-error">
                <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <span>Informasi Masih Kosong !</span>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('private', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/lawyer/resources/views/private/update/index.blade.php ENDPATH**/ ?>