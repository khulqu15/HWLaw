@extends('private')

@section('title', 'HW Lawyer - Kategori Informasi')

@section('navbar', 'Kategori Informasi')

@section('content')
<div class="w-full relative p-8 bg-white">
    <div class="space-y-3">
        <div class="flex justify-between items-center gap-x-3">
            <div class="tabs tabs-boxed">
                <a href="/private/news" class="tab">Informasi</a>
                <a href="/private/news/categories" class="tab tab-active">Kategori</a>
            </div>
            <div>
                <a href="/private/news/category/add" class="btn bg-blue-900 hover:bg-blue-700 text-white">Tambahkan baru</a>
            </div>
        </div>
        <form class="flex items-center gap-x-3 justify-between">
            <div class="w-full grow">
                <div class="form-control w-full">
                    <div class="input-group">
                        <input id="name_input" name="name" value="{{ request('name') }}" type="text" class="input text-sm w-full input-bordered" placeholder="Cari Berdasarkan Nama">
                        <button class="btn bg-primary" type="submit">
                            <iconify-icon icon="iconamoon:search-bold"></iconify-icon>
                        </button>
                    </div>
                </div>
            </div>
            <div>
                <input type="hidden" value="{{ request('sort') == 'ASC' ? 'DESC' : 'ASC' }}" name="sort">
                <button class="btn bg-ghost text-black/70" type="submit">
                    <iconify-icon icon="fa:sort"></iconify-icon>
                </button>
            </div>
        </form>
        <div>
            <div class="overflow-x-auto">
                @if ($count_categories > 0)
                <table class="table table-zebra">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Kategori</th>
                            <th>Jumlah Data</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($categories as $category)
                        <tr>
                            <th>{{ $loop->iteration }}</th>
                            <td>{{ $category->name }}</td>
                            <td>{{ count($category->post) }}</td>
                            <td class="flex items-center gap-x-3">
                                <a class="btn btn-success btn-sm" href="/private/news/category/edit/{{$category->id}}">Edit</a>
                                <form action="/private/news/category/delete/{{$category->id}}" method="POST">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button onclick="return confirm('Yakin Hapus Kategori ?')" class="btn btn-error bg-red-400 btn-sm" type="submit">Hapus</button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                <div id="pagination" class="flex space-x-3 justify-end mt-6">
                    <div class="join space-x-3">
                        {{ $categories->links() }}
                    </div>
                </div>
                @else
                <div class="alert alert-error">
                    <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    <span>Kategori Masih Kosong !</span>
                </div>
                @endif
              </div>
        </div>
    </div>
</div>
@endsection
