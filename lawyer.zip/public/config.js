const API_DOMAIN = 'http://localhost:8000';
export { API_DOMAIN };
