<?php $__env->startSection('title', 'HWLawyer - Add New Update Information'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php if(!isset($news)): ?> Tambah Informasi
    <?php else: ?> Edit Informasi
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <script type="module" src="/assets/js/custom/navbar.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white p-8 relative">
        <form id="news_form" class="space-y-4">
            <a href="/private/news" class="btn btn-ghost border border-gray-300">Kembali</a>
            <div>
                <label role="button" id="cover_label" for="cover_input" class="image_form w-full border hover:bg-gray-100 border-blue-900 relative overflow-hidden p-4 h-72 rounded-xl flex items-center justify-center">
                    <div id="cover_placeholder" class="text-center">
                        <iconify-icon class="text-4xl" icon="basil:image-outline"></iconify-icon>
                        <p>Foto HWLawyer 1</p>
                    </div>
                    <input type="file" id="cover_input" class="hidden" accept="image/png, image/jpeg">
                    <?php if(isset($news)): ?>
                        <img id="cover_preview" src="/assets/images/<?php echo e($news->cover); ?>" class="absolute image_preview w-full h-full object-cover object-center" alt="">
                    <?php endif; ?>
                </label>
                <span class="text-sm text-black/70">Klik untuk mengganti gambar</span>
            </div>
            <input id="id_input" value="<?php echo e(!isset($news) ? '' : $news->id); ?>" type="hidden">
            <div class="form-control">
                <label for="title_input" class="block mb-2">Judul Informasi</label>
                <input id="title_input" value="<?php echo e(!isset($news) ? '' : $news->title); ?>" type="text" required maxlength="42" class="input input-bordered w-full" placeholder="cth. Informasi Update Terkini Di Kota Tulungagung">
            </div>
            <div class="grid md:grid-cols-3 grid-cols-1 gap-3">
                <div class="form-control">
                    <label for="date_input" class="block mb-2">Keterangan Waktu</label>
                    <input id="date_input" value="<?php echo e(!isset($news) ? '' : date('Y-m-d', strtotime($news->date))); ?>" type="date" required class="input input-bordered w-full" placeholder="cth. Informasi Update Terkini Di Kota Tulungagung">
                </div>
                <div class="form-control">
                    <label for="location_input" class="block mb-2">Keterangan Tempat</label>
                    <input id="location_input" value="<?php echo e(!isset($news) ? '' : $news->location); ?>" type="text" required maxlength="150" class="input input-bordered w-full" placeholder="cth. Sukolilo, Surabaya">
                </div>
                <div class="form-control">
                    <label for="category_input" class="block mb-2">Kategori Informasi</label>
                    <select id="category_input" required class="select select-bordered w-full">
                        <option value="">Pilih kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php if(isset($news)): ?>
                            <?php echo e($category->id == $news->category_post_id ? 'selected' : ''); ?>

                        <?php endif; ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div>
                <label for="description_input" class="block mb-2">Isi Informasi</label>
                <div id="quil_editor"><?php echo !isset($news) ? '' : $news->text; ?></div>
            </div>
            <div class="w-full mt-3 flex justify-end justify-items-end items-center gap-x-3">
                <a href="/private/news" class="btn btn-ghost border border-gray-300">Batal</a>
                <button class="btn bg-blue-900 hover:bg-blue-800 btn-wide text-white" type="sumbit">Simpan</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script>
var toolbarOptions = [
    ['bold', 'italic', 'underline'],
    [{'header': 1}, {'header': 2}],
    [{'list': 'ordered'}, {'list': 'bullet'}],
    [{'script': 'sub'}, {'script': 'super'}],
    [{'indent': '-1'}, {'indent': '+1'}],
    [{'direction': 'rtl'}],

    [{'size': ['small', false, 'large', 'huge']}],
    [{'header': [1, 2, 3, 4, 5, 6, false]}],

    [{'color': []}, {'background': []}],
    [{'font': []}],
    [{'align': []}],

    ['link', 'image', 'video'],
];

var quill = new Quill('#quil_editor', {
    theme: 'snow',
    modules: {
        toolbar: toolbarOptions
    }
});

function showToast(type, msg) {
    const toast = document.querySelector('.toast');
    const successToast = toast.querySelector('.alert-success');
    const errorToast = toast.querySelector('.alert-danger');
    if(type == 'success') {
        successToast.querySelector('span').textContent = msg;
        successToast.classList.remove('hidden');
        setTimeout(() => {
            successToast.classList.add('hidden');
        }, 3000);
    } else if(type == 'error') {
        errorToast.querySelector('span').textContent = msg;
        errorToast.classList.remove('hidden');
        setTimeout(() => {
            errorToast.classList.add('hidden');
        }, 3000);
    }
}


document.getElementById('news_form').addEventListener('submit', function(e) {
    e.preventDefault()
    const title_input = document.getElementById('title_input').value
    const date_input = document.getElementById('date_input').value
    const location_input = document.getElementById('location_input').value
    const category_input = document.getElementById('category_input').value
    const cover_input = document.getElementById('cover_input')
    const description_input = quill.root.innerHTML
    const id = document.getElementById('id_input').value
    let endpoint = ''
    if(id == '') endpoint = '/private/news/store'
    else endpoint = '/private/news/update/'+id


    const formData = new FormData()
    formData.append('title', title_input)
    formData.append('date', date_input)
    formData.append('location', location_input)
    formData.append('cover', cover_input.files[0])
    formData.append('category_post_id', category_input)
    formData.append('text', description_input)

    fetch(endpoint, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.status == 'success') {
            showToast('success', data.message)
            image1Input.value = ''
            image2Input.value = ''
        }
        else showToast('error', data.message)
    }).catch(error => {
        showToast('error', error)
    })
})
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('private', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/lawyer/resources/views/private/update/form.blade.php ENDPATH**/ ?>