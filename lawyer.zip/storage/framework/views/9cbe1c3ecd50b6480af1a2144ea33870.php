<?php $__env->startSection('title', 'HW Lawyer - Admin Kontak'); ?>

<?php $__env->startSection('navbar', 'Kontak Link'); ?>

<?php $__env->startSection('footer_script'); ?>
<script type="module" src="/assets/js/custom/news.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full relative p-8 bg-white">
    <div class="space-y-3">
        <div>
            <a href="/private/link/add" class="btn bg-blue-900 hover:bg-blue-700 text-white">Tambahkan baru</a>
        </div>
        <div>
            <div class="overflow-x-auto">
                <?php if($count_links > 0): ?>
                <table class="table table-zebra">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Nama</th>
                            <th>Kategori</th>
                            <th>Link</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($link->name); ?></td>
                            <td><?php echo e($link->category); ?></td>
                            <td><?php echo e($link->link); ?></td>
                            <td class="flex items-center gap-x-3">
                                <a class="btn btn-success btn-sm" href="/private/link/edit/<?php echo e($link->id); ?>">Edit</a>
                                <form action="/private/link/delete/<?php echo e($link->id); ?>" method="POST">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button onclick="return confirm('Yakin Hapus Kategori ?')" class="btn btn-error bg-red-400 btn-sm" type="submit">Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="alert alert-error">
                    <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    <span>Kontak Link Masih Kosong !</span>
                </div>
                <?php endif; ?>
              </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('private', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/lawyer/resources/views/private/link/index.blade.php ENDPATH**/ ?>